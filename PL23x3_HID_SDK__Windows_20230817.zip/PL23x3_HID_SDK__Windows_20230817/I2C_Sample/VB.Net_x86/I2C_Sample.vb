﻿Imports System.Runtime.InteropServices

Module Module1
    Const PROLIFIC_VID As UShort = &H67B
    Const ERROR_SUCCESS As Int32 = 0
    Const ERROR_INSUFFICIENT_BUFFER As Int32 = -1
    Const ERROR_READ_REGISTER_FAIL As Int32 = -2
    Const ERROR_WRITE_REGISTER_FAIL As Int32 = -3
    Const ERROR_READ_DATA_FAIL As Int32 = -4
    Const ERROR_READ_TIMEOUT As Int32 = -5
    Const ERROR_WRITE_DATA_FAIL As Int32 = -6
    Const ERROR_WRITE_TIMEOUT As Int32 = -7
    Const ERROR_DEVICE_NOT_EXIST As Int32 = -8
    Const ERROR_NOT_GPIO_PIN As Int32 = -9
    Const ERROR_DEVICE_OPEN_FAIL As Int32 = -10
    Const ERROR_DATA_LENGTH_TOO_LARGE As Int32 = -11
    Const ERROR_OTHER_FAIL As Int32 = -12
    Const ERROR_I2C_BUS_BUSY As Int32 = -13
    Const ERROR_I2C_ADDRESS_NACK As Int32 = -14
    Const ERROR_I2C_DATA_NACK As Int32 = -15
    Const ERROR_I2C_PROCESSING As Int32 = -16

    <DllImport("HidDeviceSdk.dll")> _
    Public Function EnumDeviceByVid(ByRef HidDeviceCount As UInteger, ByVal VID As UShort) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function OpenDeviceHandle(ByVal DeviceIndex As UInteger, ByRef hDeviceHandle As IntPtr) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function CloseDeviceHandle(ByVal hDeviceHandle As IntPtr) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function SetI2CDeviceAddress(ByVal hDeviceHandle As IntPtr, ByVal DeviceAddress As Byte) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function SetI2CFrequency(ByVal hDeviceHandle As IntPtr, ByVal FreqDiv As Byte) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function I2CRead(ByVal hDeviceHandle As IntPtr, ByRef ReadBuffer As Byte, _
                            ByVal NumberOfBytesToRead As UInteger, ByRef NumberOfBytesRead As UInteger, _
                            ByVal TimeOutms As UInteger) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function I2CWrite(ByVal hDeviceHandle As IntPtr, ByRef WriteBuffer As Byte, _
                            ByVal NumberOfBytesToWrite As UInteger, ByRef NumberOfBytesWritten As UInteger, _
                            ByVal TimeOutms As UInteger) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function I2CWriteRead(ByVal hDeviceHandle As IntPtr, ByRef WriteBuffer As Byte, _
                        ByVal NumberOfBytesToWrite As UInteger, ByRef ReadBuffer As Byte, ByVal NumberOfBytesToRead As UInteger, _
                        ByRef NumberOfBytesUse As UInteger, ByVal TimeOutms As UInteger) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function I2CReset(ByVal hDeviceHandle As IntPtr) As Int32
    End Function

    Sub Main()
        Dim nHidDeviceCount As UInteger = 0
        Dim hDeviceHandle As IntPtr = -1
        Dim nRet As UInteger = 0
        'Step1: Enum Device (&067B ==> USB VID)
        nRet = EnumDeviceByVid(nHidDeviceCount, PROLIFIC_VID)
        If ERROR_SUCCESS = nRet Then
            If nHidDeviceCount > 0 Then
                'Step2: Open Hid Device Array index, ex: 0
                nRet = OpenDeviceHandle(0, hDeviceHandle)
                If ERROR_SUCCESS = nRet Then
                    Dim by7BitDeviceAddress As Byte = &HA0
                    nRet = SetI2CDeviceAddress(hDeviceHandle, by7BitDeviceAddress)
                    If ERROR_SUCCESS = nRet Then
                        Console.WriteLine("Set I2C 7Bit DeviceAddress=0x{0:X}", by7BitDeviceAddress)
                    Else
                        Console.WriteLine("SetI2CDeviceAddress Fail")
                    End If

                    'Set I2C Frequency
                    'nI2CFreqDiv = 4, I2C Frequency(KHz) = 24000/4 = 6 Mhz(Max)
                    'nI2CFreqDiv = 255, I2C Frequency(KHz) = 24000/254 = 94 Khz(Min)  
                    Dim byI2CFreqDiv As Byte = 100   '100 ==> 240000 Hz
                    nRet = SetI2CFrequency(hDeviceHandle, byI2CFreqDiv)
                    If ERROR_SUCCESS = nRet Then
                        Console.WriteLine("Set I2C Frequency={0:D} Hz", Convert.ToInt32((24000000 / byI2CFreqDiv)))
                    Else
                        Console.WriteLine("SetI2CFrequency Fail")
                    End If

                    'AT24C02, PageWrite
                    'Send I2C Word Address 0x00, Data = {0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37};
                    Dim byWriteBuffer() As Byte = {&H0, &H31, &H32, &H33, &H34, &H35, &H36, &H37}
                    Dim byHidWritePacketSize As Byte = 8
                    Dim nRealDataLen As UShort = 0
                    Dim nTimeOutMs As UInteger = 1000
                    nRet = I2CWrite(hDeviceHandle, byWriteBuffer(0), byHidWritePacketSize, _
                                    nRealDataLen, nTimeOutMs)

                    If ERROR_SUCCESS = nRet Then
                        Console.Write("I2C Page Write, WordAddress=0x{0:X}, Data=", byWriteBuffer(0))
                        For n As Integer = 1 To 7
                            Console.Write("0x{0:X} ", byWriteBuffer(n))
                        Next
                        Console.WriteLine("")
                    Else
                        Console.WriteLine("I2CWrite Fail")
                    End If

                    'AT24C02, Random Read 
                    'Write 1 byte Word Address
                    Dim byWordAddress As Byte = &H0
                    Dim byReadBuffer(7) As Byte
                    Dim nNumberOfBytesToRead As UInteger = 7
                    nRet = I2CWriteRead(hDeviceHandle, byWordAddress, &H1, byReadBuffer(0), _
                                        nNumberOfBytesToRead, nRealDataLen, nTimeOutMs)
                    If ERROR_SUCCESS = nRet Then
                        Console.Write("I2C Random Read, WordAddress=0x{0:X}, Data=", byWordAddress)
                        For n As Integer = 0 To 6
                            Console.Write("0x{0:X} ", byReadBuffer(n))
                        Next
                        Console.WriteLine("")
                    Else
                        Console.WriteLine("I2C Random Read Fail")
                    End If
                    nRet = CloseDeviceHandle(hDeviceHandle)
                Else
                    Console.WriteLine("Open Device Fail!")
                End If
            Else
                Console.WriteLine("No match Hid device!")
            End If
        Else
            Console.WriteLine("EnumDeviceByVid fail")
        End If
        Console.ReadLine()
    End Sub

End Module
